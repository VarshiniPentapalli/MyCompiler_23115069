#include <iostream>
extern int yyparse();

int main() {
    std::cout << "Enter an expression like: x = (a + b) * (a + b + c)" << std::endl;
    yyparse();
    return 0;
}

